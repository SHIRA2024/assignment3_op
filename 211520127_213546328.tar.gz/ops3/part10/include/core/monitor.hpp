#pragma once

void* monitorCH(void*);
